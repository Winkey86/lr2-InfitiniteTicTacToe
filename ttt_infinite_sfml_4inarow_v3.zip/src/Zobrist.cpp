#include "Zobrist.hpp"
// header-only style; translation unit to satisfy build systems
